Simple Modern UI Web built on with combine pure css and js
